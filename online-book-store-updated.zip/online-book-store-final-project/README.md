# PageTurner – Online Book Store

A responsive full-stack Online Book Store built with **HTML, CSS, JavaScript, Node.js, Express.js and MongoDB**.

## Features

- Responsive home page and book catalogue
- Search books by title, author or category
- Filter by category and sort by price or newest
- User registration and login with hashed passwords
- JWT authentication and protected routes
- Shopping cart saved in the browser
- Checkout and order placement
- Each user can view only their own order history
- Admin-protected create, update and delete book APIs
- Admin-protected order listing API
- Sample books are inserted automatically on first start
- Render deployment configuration included

## Project structure

```text
online-book-store/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── render.yaml
├── server.js
└── README.md
```

## Run locally

1. Install Node.js (LTS) and MongoDB, or create a free MongoDB Atlas database.
2. Open this folder in VS Code.
3. Open the terminal and run:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`.
5. Add your MongoDB connection string and a long private JWT secret in `.env`.
6. Add an admin email and password in `.env`.
7. Start the application:

   ```bash
   npm start
   ```

8. Open `http://localhost:5000`.

**Important:** Never upload `.env` to GitHub. `.gitignore` already excludes it. Do not publish real passwords or database credentials.

## Environment variables

| Variable | Purpose |
|---|---|
| `PORT` | Server port (Render supplies this automatically) |
| `MONGODB_URI` | MongoDB Atlas connection string |
| `JWT_SECRET` | Private secret used to sign login tokens |
| `ADMIN_NAME` | Initial admin display name |
| `ADMIN_EMAIL` | Initial admin email |
| `ADMIN_PASSWORD` | Initial admin password |

## Admin book management API

The initial admin account is created from the `ADMIN_*` environment variables when the server starts. Sign in through the website to obtain a JWT, then use the token as `Authorization: Bearer YOUR_TOKEN`.

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/api/books` | Add a book (admin) |
| `PUT` | `/api/books/:id` | Update a book (admin) |
| `DELETE` | `/api/books/:id` | Delete a book (admin) |
| `GET` | `/api/orders` | View all orders (admin) |

Example JSON for creating a book:

```json
{
  "title": "Deep Work",
  "author": "Cal Newport",
  "category": "Productivity",
  "price": 350,
  "description": "Rules for focused success.",
  "image": "https://example.com/book-cover.jpg",
  "stock": 10,
  "featured": true
}
```

## Deploy on Render

1. Push this project to a GitHub repository.
2. Create a MongoDB Atlas database and allow network access for Render (for a learning project, Atlas network access can be set to `0.0.0.0/0`; use appropriate database credentials).
3. In Render, choose **New → Web Service** and connect your GitHub repository.
4. Build command: `npm install`
5. Start command: `npm start`
6. Add environment variables in Render:
   - `MONGODB_URI`
   - `JWT_SECRET` (use a long random value)
   - `ADMIN_EMAIL`
   - `ADMIN_PASSWORD`
   - `ADMIN_NAME`
7. Deploy. Render will provide your public website URL.

The `render.yaml` file is included as a deployment blueprint. Keep secrets in Render's environment settings, not in GitHub.

## API overview

| Method | Endpoint | Access |
|---|---|---|
| `GET` | `/api/health` | Public |
| `POST` | `/api/auth/register` | Public |
| `POST` | `/api/auth/login` | Public |
| `GET` | `/api/auth/me` | Logged-in user |
| `GET` | `/api/books` | Public |
| `GET` | `/api/books/:id` | Public |
| `POST` | `/api/orders` | Logged-in user |
| `GET` | `/api/orders/my` | Logged-in user |

## Notes

- This is an educational internship project starter. Test it thoroughly before using it for real customers or payments.
- Checkout records orders; it does not process online payments.
- Book cover images use remote image URLs. Replace them with images you have permission to use.
- For production use, add rate limiting, stronger input validation, email verification, payment integration, and a more robust inventory transaction strategy.

## Author

**Student Project – Online Book Store**  
Department of Computer Science  
Government First Grade College for Women, Jamkhandi  
Affiliated to Akka Mahadevi University


## Updated features
- Contact Us form (messages are logged in the server console; configure an email provider for inbox delivery).
- Admin dashboard for book create, edit and delete, plus store summary and recent orders.
- About Us and responsive Contact sections.
- Admin account is created from ADMIN_EMAIL and ADMIN_PASSWORD environment variables on first startup.

## Additional API setup
The server already includes protected admin routes. Set the admin credentials in `.env` before first run. The contact endpoint is `POST /api/contact`.
