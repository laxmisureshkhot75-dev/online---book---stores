require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "development_only_change_me";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["user", "admin"], default: "user" }
}, { timestamps: true });

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  author: { type: String, required: true, trim: true },
  category: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  description: { type: String, default: "" },
  image: { type: String, default: "" },
  stock: { type: Number, default: 10, min: 0 },
  featured: { type: Boolean, default: false }
}, { timestamps: true });

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [{
    book: { type: mongoose.Schema.Types.ObjectId, ref: "Book" },
    title: String,
    price: Number,
    quantity: Number
  }],
  total: { type: Number, required: true },
  shippingAddress: { type: String, required: true },
  status: { type: String, enum: ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"], default: "Placed" }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Book = mongoose.model("Book", bookSchema);
const Order = mongoose.model("Order", orderSchema);

function createToken(user) {
  return jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
}
async function auth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: "Please log in first." });
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
    if (!req.user) return res.status(401).json({ message: "Account not found." });
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired login. Please log in again." });
  }
}
function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ message: "Admin access required." });
  next();
}
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get("/api/health", (req, res) => res.json({ status: "ok", message: "Online Book Store API is running." }));

app.post("/api/auth/register", asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required." });
  if (password.length < 6) return res.status(400).json({ message: "Password must contain at least 6 characters." });
  const normalizedEmail = email.toLowerCase().trim();
  if (await User.findOne({ email: normalizedEmail })) return res.status(409).json({ message: "This email is already registered." });
  const hashed = await bcrypt.hash(password, 12);
  const user = await User.create({ name, email: normalizedEmail, password: hashed });
  res.status(201).json({ token: createToken(user), user: { id: user._id, name: user.name, email: user.email, role: user.role } });
}));

app.post("/api/auth/login", asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: (email || "").toLowerCase().trim() });
  if (!user || !(await bcrypt.compare(password || "", user.password))) return res.status(401).json({ message: "Incorrect email or password." });
  res.json({ token: createToken(user), user: { id: user._id, name: user.name, email: user.email, role: user.role } });
}));
app.get("/api/auth/me", auth, (req, res) => res.json({ user: req.user }));

app.get("/api/books", asyncHandler(async (req, res) => {
  const { search = "", category = "", sort = "" } = req.query;
  const filter = {};
  if (category && category !== "All") filter.category = category;
  if (search) filter.$or = [
    { title: { $regex: search, $options: "i" } },
    { author: { $regex: search, $options: "i" } },
    { category: { $regex: search, $options: "i" } }
  ];
  let query = Book.find(filter);
  if (sort === "price-low") query = query.sort({ price: 1 });
  else if (sort === "price-high") query = query.sort({ price: -1 });
  else if (sort === "newest") query = query.sort({ createdAt: -1 });
  else query = query.sort({ featured: -1, createdAt: -1 });
  res.json({ books: await query });
}));
app.get("/api/books/:id", asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) return res.status(404).json({ message: "Book not found." });
  res.json({ book });
}));
app.post("/api/books", auth, adminOnly, asyncHandler(async (req, res) => {
  const book = await Book.create(req.body);
  res.status(201).json({ book });
}));
app.put("/api/books/:id", auth, adminOnly, asyncHandler(async (req, res) => {
  const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!book) return res.status(404).json({ message: "Book not found." });
  res.json({ book });
}));
app.delete("/api/books/:id", auth, adminOnly, asyncHandler(async (req, res) => {
  const book = await Book.findByIdAndDelete(req.params.id);
  if (!book) return res.status(404).json({ message: "Book not found." });
  res.json({ message: "Book deleted successfully." });
}));

app.post("/api/orders", auth, asyncHandler(async (req, res) => {
  const { items, shippingAddress } = req.body;
  if (!Array.isArray(items) || !items.length || !shippingAddress?.trim()) return res.status(400).json({ message: "Cart items and shipping address are required." });
  const orderItems = [];
  let total = 0;
  for (const item of items) {
    const quantity = Math.max(1, Math.floor(Number(item.quantity) || 1));
    const book = await Book.findById(item.bookId);
    if (!book) return res.status(400).json({ message: "One of the selected books is no longer available." });
    if (book.stock < quantity) return res.status(400).json({ message: `Only ${book.stock} copies of ${book.title} are available.` });
    orderItems.push({ book: book._id, title: book.title, price: book.price, quantity });
    total += book.price * quantity;
    book.stock -= quantity;
    await book.save();
  }
  const order = await Order.create({ user: req.user._id, items: orderItems, total, shippingAddress });
  res.status(201).json({ message: "Order placed successfully.", order });
}));
app.get("/api/orders/my", auth, asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json({ orders });
}));
app.get("/api/orders", auth, adminOnly, asyncHandler(async (req, res) => {
  const orders = await Order.find().populate("user", "name email").sort({ createdAt: -1 });
  res.json({ orders });
}));

app.post("/api/contact", (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ message: "Please complete all fields." });
  console.log("CONTACT MESSAGE:", { name, email, message, receivedAt: new Date().toISOString() });
  res.status(201).json({ message: "Thank you. Your message has been received." });
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 11000) return res.status(409).json({ message: "That email is already registered." });
  if (err.name === "CastError") return res.status(400).json({ message: "Invalid ID." });
  res.status(500).json({ message: "Server error. Please try again." });
});

async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) return;
  const existing = await User.findOne({ email });
  if (!existing) {
    const hashed = await bcrypt.hash(password, 12);
    await User.create({ name: process.env.ADMIN_NAME || "Store Admin", email, password: hashed, role: "admin" });
    console.log("Admin account created from environment settings.");
  } else if (existing.role !== "admin") {
    existing.role = "admin";
    await existing.save();
  }
}
async function seedBooks() {
  if (await Book.countDocuments()) return;
  await Book.insertMany([
    { title: "The Alchemist", author: "Paulo Coelho", category: "Motivational", price: 299, stock: 20, featured: true, description: "A memorable journey about dreams, courage and finding your purpose.", image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600" },
    { title: "Wings of Fire", author: "A. P. J. Abdul Kalam", category: "Biography", price: 250, stock: 18, featured: true, description: "The inspiring autobiography of India's former President and scientist.", image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600" },
    { title: "Atomic Habits", author: "James Clear", category: "Self Help", price: 399, stock: 15, featured: true, description: "Practical strategies for building good habits and breaking bad ones.", image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600" },
    { title: "Ramayana: The Epic", author: "Valmiki", category: "Devotional", price: 349, stock: 12, description: "A retelling of the timeless Indian epic.", image: "https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=600" },
    { title: "The Psychology of Money", author: "Morgan Housel", category: "Finance", price: 320, stock: 14, description: "Timeless lessons on wealth, greed and happiness.", image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=600" },
    { title: "Learn Python the Easy Way", author: "A. Sharma", category: "Education", price: 280, stock: 25, description: "A beginner-friendly introduction to Python programming.", image: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=600" }
  ]);
}
mongoose.connect(process.env.MONGODB_URI)
  .then(async () => {
    console.log("MongoDB connected.");
    await seedAdmin();
    await seedBooks();
    app.listen(PORT, () => console.log(`Online Book Store running on port ${PORT}`));
  })
  .catch(err => {
    console.error("MongoDB connection failed. Check MONGODB_URI in your .env file.", err.message);
    process.exit(1);
  });
