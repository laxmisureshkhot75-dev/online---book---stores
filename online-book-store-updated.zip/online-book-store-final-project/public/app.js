const API = "/api";
let token = localStorage.getItem("pt_token") || "";
let currentUser = JSON.parse(localStorage.getItem("pt_user") || "null");
let cart = JSON.parse(localStorage.getItem("pt_cart") || "[]");
let books = [];
let registerMode = false;
const $ = id => document.getElementById(id);
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const headers = () => ({ "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) });

async function api(url, options = {}) {
  const response = await fetch(API + url, { ...options, headers: { ...headers(), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2400);
}
function modal(id, show = true) { $(id).classList.toggle("hidden", !show); }
function saveCart() { localStorage.setItem("pt_cart", JSON.stringify(cart)); updateCartCount(); }
function updateCartCount() { $("cartCount").textContent = cart.reduce((sum, x) => sum + x.quantity, 0); }
function updateUserUI() {
  $("loginBtn").classList.toggle("hidden", !!currentUser);
  $("logoutBtn").classList.toggle("hidden", !currentUser);
  $("ordersBtn").classList.toggle("hidden", !currentUser);
  $("adminBtn").classList.toggle("hidden", currentUser?.role !== "admin");
}
function bookCard(book) {
  const image = book.image || "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600";
  return `<article class="book-card"><div class="cover"><img src="${image}" alt="${escapeHtml(book.title)} cover" loading="lazy" onerror="this.style.display='none'"></div><div class="book-info"><span class="category">${escapeHtml(book.category)}</span><h3>${escapeHtml(book.title)}</h3><div class="author">by ${escapeHtml(book.author)}</div><p class="description">${escapeHtml(book.description || "A wonderful addition to your reading list.")}</p><div class="book-footer"><span class="price">${money(book.price)}</span><button class="add-btn" data-add="${book._id}" ${book.stock <= 0 ? "disabled" : ""}>${book.stock <= 0 ? "Out of stock" : "＋ Add to cart"}</button></div></div></article>`;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
async function loadBooks() {
  $("bookGrid").innerHTML = '<p class="loading">Loading books...</p>';
  try {
    const params = new URLSearchParams();
    if ($("searchInput").value.trim()) params.set("search", $("searchInput").value.trim());
    if ($("categoryFilter").value) params.set("category", $("categoryFilter").value);
    if ($("sortFilter").value) params.set("sort", $("sortFilter").value);
    const data = await api("/books?" + params.toString());
    books = data.books;
    $("bookGrid").innerHTML = books.length ? books.map(bookCard).join("") : '<p class="loading">No books found. Try another search.</p>';
    const selected = $("categoryFilter").value;
    const categories = ["All", ...new Set(books.map(b => b.category))];
    $("categoryFilter").innerHTML = categories.map(c => `<option ${c === selected ? "selected" : ""}>${escapeHtml(c)}</option>`).join("");
  } catch (e) { $("bookGrid").innerHTML = `<p class="loading">${escapeHtml(e.message)}</p>`; }
}
function addToCart(id) {
  const book = books.find(b => b._id === id);
  if (!book) return;
  const existing = cart.find(x => x.bookId === id);
  if (existing) existing.quantity += 1;
  else cart.push({ bookId: id, title: book.title, price: book.price, image: book.image, quantity: 1 });
  saveCart(); toast("Added to your cart.");
}
function renderCart() {
  const total = cart.reduce((sum, x) => sum + x.price * x.quantity, 0);
  $("cartItems").innerHTML = cart.length ? cart.map(x => `<div class="cart-row"><div><b>${escapeHtml(x.title)}</b><small>${money(x.price)} each</small></div><div class="qty"><button data-qty="${x.bookId}" data-change="-1">−</button><b>${x.quantity}</b><button data-qty="${x.bookId}" data-change="1">+</button><button data-remove="${x.bookId}" aria-label="Remove">×</button></div></div>`).join("") : "<p>Your cart is empty. Browse the bookshelf to add a book.</p>";
  $("cartTotal").textContent = "Total: " + money(total);
  $("checkoutBtn").disabled = !cart.length;
}
function openAuth(mode = false) {
  registerMode = mode; $("authTitle").textContent = mode ? "Create account" : "Login";
  $("authSubmit").textContent = mode ? "Create account" : "Login";
  $("nameWrap").classList.toggle("hidden", !mode);
  $("authPassword").autocomplete = mode ? "new-password" : "current-password";
  $("switchAuth").innerHTML = mode ? 'Already registered? <button id="toggleAuth">Login</button>' : 'New here? <button id="toggleAuth">Create an account</button>';
  $("authMessage").textContent = ""; modal("authModal");
  $("toggleAuth").onclick = () => openAuth(!registerMode);
}
async function submitAuth(event) {
  event.preventDefault(); $("authMessage").textContent = "Please wait...";
  try {
    const payload = { email: $("authEmail").value, password: $("authPassword").value };
    if (registerMode) payload.name = $("authName").value;
    const data = await api(registerMode ? "/auth/register" : "/auth/login", { method: "POST", body: JSON.stringify(payload) });
    token = data.token; currentUser = data.user;
    localStorage.setItem("pt_token", token); localStorage.setItem("pt_user", JSON.stringify(currentUser));
    updateUserUI(); modal("authModal", false); $("authForm").reset(); toast("Welcome, " + currentUser.name + "!");
  } catch (e) { $("authMessage").textContent = e.message; }
}
async function showOrders() {
  modal("ordersModal"); $("ordersList").innerHTML = "Loading orders...";
  try {
    const data = await api("/orders/my");
    $("ordersList").innerHTML = data.orders.length ? data.orders.map(o => `<div class="order-card"><b>Order · ${new Date(o.createdAt).toLocaleDateString()}</b><p>${o.items.map(i => `${escapeHtml(i.title)} × ${i.quantity}`).join("<br>")}<br><b>Total: ${money(o.total)}</b><br>Status: ${escapeHtml(o.status)}<br>Delivery: ${escapeHtml(o.shippingAddress)}</p></div>`).join("") : "<p>You have not placed any orders yet.</p>";
  } catch (e) { $("ordersList").textContent = e.message; }
}
async function placeOrder(event) {
  event.preventDefault(); $("checkoutMessage").textContent = "Placing your order...";
  try {
    await api("/orders", { method: "POST", body: JSON.stringify({ items: cart.map(x => ({ bookId: x.bookId, quantity: x.quantity })), shippingAddress: $("shippingAddress").value }) });
    cart = []; saveCart(); modal("checkoutModal", false); modal("cartModal", false); $("checkoutForm").reset(); toast("Your order has been placed!"); loadBooks();
  } catch (e) { $("checkoutMessage").textContent = e.message; }
}
function logout() {
  token = ""; currentUser = null; localStorage.removeItem("pt_token"); localStorage.removeItem("pt_user"); updateUserUI(); $("adminPanel").classList.add("hidden"); toast("You have logged out.");
}


async function sendContact(event) {
  event.preventDefault(); $("contactFeedback").textContent = "Sending...";
  try { const d = await api("/contact", {method:"POST", body:JSON.stringify({name:$("contactName").value,email:$("contactEmail").value,message:$("contactMessage").value})}); $("contactFeedback").textContent=d.message; $("contactForm").reset(); }
  catch(e) { $("contactFeedback").textContent=e.message; }
}
function resetBookForm(){ $("bookForm").reset(); $("editBookId").value=""; $("bookStock").value=10; $("bookFormTitle").textContent="Add a book"; $("cancelEdit").classList.add("hidden"); }
async function loadAdmin(){
  if(currentUser?.role!=="admin") return;
  $("adminPanel").classList.remove("hidden"); $("adminPanel").scrollIntoView({behavior:"smooth"});
  try {
    const [summary, bookData, orderData] = await Promise.all([api("/api/admin/summary"), api("/books"), api("/api/orders")]);
    $("adminStats").innerHTML = [["Books",summary.books],["Customers",summary.users],["Orders",summary.orders],["Revenue",money(summary.revenue)]].map(x=>`<div class="stat-card"><small>${x[0]}</small><b>${x[1]}</b></div>`).join("");
    $("adminBookList").innerHTML = bookData.books.map(b=>`<div class="manage-row"><span><b>${escapeHtml(b.title)}</b><small>${money(b.price)} · Stock ${b.stock}</small></span><span><button class="mini-btn" data-edit="${b._id}">Edit</button> <button class="mini-btn danger" data-delete="${b._id}">Delete</button></span></div>`).join("") || "No books found.";
    $("adminOrderList").innerHTML = orderData.orders.slice(0,8).map(o=>`<div class="manage-row"><span><b>${escapeHtml(o.user?.name || "Customer")}</b><small>${money(o.total)} · ${escapeHtml(o.status)}</small></span><small>${new Date(o.createdAt).toLocaleDateString()}</small></div>`).join("") || "No orders yet.";
  } catch(e) { $("adminFeedback").textContent=e.message; }
}
async function saveBook(event){
  event.preventDefault(); const id=$("editBookId").value;
  const body={title:$("bookTitle").value,author:$("bookAuthor").value,category:$("bookCategory").value,price:Number($("bookPrice").value),stock:Number($("bookStock").value),image:$("bookImage").value,description:$("bookDescription").value};
  try { await api(id?"/books/"+id:"/books",{method:id?"PUT":"POST",body:JSON.stringify(body)}); $("adminFeedback").textContent="Book saved successfully."; resetBookForm(); await loadAdmin(); await loadBooks(); }
  catch(e){ $("adminFeedback").textContent=e.message; }
}
async function editBook(id){
  try { const b=(await api("/books/"+id)).book; $("editBookId").value=b._id; $("bookTitle").value=b.title; $("bookAuthor").value=b.author; $("bookCategory").value=b.category; $("bookPrice").value=b.price; $("bookStock").value=b.stock; $("bookImage").value=b.image||""; $("bookDescription").value=b.description||""; $("bookFormTitle").textContent="Edit book"; $("cancelEdit").classList.remove("hidden"); $("bookForm").scrollIntoView({behavior:"smooth"}); }
  catch(e){toast(e.message)}
}
async function deleteBook(id){ if(!confirm("Delete this book?"))return; try{await api("/books/"+id,{method:"DELETE"});toast("Book deleted.");await loadAdmin();await loadBooks()}catch(e){toast(e.message)} }

document.addEventListener("click", event => {
  const edit = event.target.closest("[data-edit]"); if(edit) editBook(edit.dataset.edit);
  const del = event.target.closest("[data-delete]"); if(del) deleteBook(del.dataset.delete);
  const add = event.target.closest("[data-add]"); if (add) addToCart(add.dataset.add);
  const remove = event.target.closest("[data-remove]");
  if (remove) { cart = cart.filter(x => x.bookId !== remove.dataset.remove); saveCart(); renderCart(); }
  const qty = event.target.closest("[data-qty]");
  if (qty) { const item = cart.find(x => x.bookId === qty.dataset.qty); item.quantity += Number(qty.dataset.change); if (item.quantity <= 0) cart = cart.filter(x => x !== item); saveCart(); renderCart(); }
  const close = event.target.closest("[data-close]"); if (close) modal(close.dataset.close, false);
});
$("loginBtn").onclick = () => openAuth(false);
$("logoutBtn").onclick = logout;
$("ordersBtn").onclick = showOrders;
$("adminBtn").onclick = loadAdmin;
$("closeAdmin").onclick = () => $("adminPanel").classList.add("hidden");
$("bookForm").addEventListener("submit", saveBook);
$("cancelEdit").onclick = resetBookForm;
$("contactForm").addEventListener("submit", sendContact);
$("cartBtn").onclick = () => { renderCart(); modal("cartModal"); };
$("checkoutBtn").onclick = () => { if (!currentUser) { modal("cartModal", false); openAuth(false); $("authMessage").textContent = "Please log in to place your order."; return; } modal("cartModal", false); modal("checkoutModal"); };
$("authForm").addEventListener("submit", submitAuth);
$("checkoutForm").addEventListener("submit", placeOrder);
$("searchInput").addEventListener("input", () => { clearTimeout(loadBooks.timer); loadBooks.timer = setTimeout(loadBooks, 300); });
$("categoryFilter").addEventListener("change", loadBooks);
$("sortFilter").addEventListener("change", loadBooks);
$("year").textContent = new Date().getFullYear();
updateCartCount(); updateUserUI(); loadBooks();
